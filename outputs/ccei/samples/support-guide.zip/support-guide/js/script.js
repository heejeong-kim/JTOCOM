// 화면 요소 가져오기
const stageSelect = document.getElementById("stage");
const fieldSelect = document.getElementById("field");
const list = document.getElementById("list");
const count = document.getElementById("count");

// 지원사업 카드 그리기
function render(items) {
  count.textContent = items.length;
  if (items.length === 0) {
    list.innerHTML = '<p class="empty">고른 조건에 맞는 지원사업이 없어요. 조건을 바꿔 보세요.</p>';
    return;
  }
  list.innerHTML = items.map(function (p) {
    const tags = p.stage.concat(p.field.length > 3 ? ["모든 업종"] : p.field);
    return '<article class="card">' +
      '<span class="cat">' + p.category + '</span>' +
      '<h4>' + p.name + '</h4>' +
      '<p>' + p.summary + '</p>' +
      '<div class="tags">' + tags.map(function (t) { return '<span>' + t + '</span>'; }).join("") + '</div>' +
      '<div class="benefit">' + p.benefit + '</div>' +
    '</article>';
  }).join("");
}

// '추천 받기' 버튼: 고른 조건에 맞는 사업만 보여 주기
document.getElementById("recommend").addEventListener("click", function () {
  const stage = stageSelect.value;
  const field = fieldSelect.value;
  const result = programs.filter(function (p) {
    const stageOk = !stage || p.stage.includes(stage);
    const fieldOk = !field || p.field.includes(field);
    return stageOk && fieldOk;
  });
  render(result);
});

// 처음 열면 모든 사업 보여 주기
render(programs);
